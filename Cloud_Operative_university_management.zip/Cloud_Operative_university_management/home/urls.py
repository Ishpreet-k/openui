# urls.py

from django.urls import path
from . import views

app_name = 'home'

urlpatterns = [
    # User Account Management
    path('', views.index, name ='index'),
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),
    path('logout/', views.logout_view, name='logout'),
    path('user-accounts/', views.user_account_list, name='user_account_list'),
    path('user-accounts/<int:pk>/', views.user_account_detail, name='user_account_detail'),
    path('user-accounts/<int:pk>/update/', views.user_account_update, name='user_account_update'),

    # University Service Management
    path('university-services/', views.university_service_list, name='university_service_list'),
    path('university-services/<int:pk>/', views.university_service_detail, name='university_service_detail'),
    path('university-services/<int:pk>/update/', views.university_service_update, name='university_service_update'),

    # Financial Management
    path('financial-transactions/', views.financial_transaction_list, name='financial_transaction_list'),
    path('financial-transactions/<int:pk>/update/', views.financial_transaction_update, name='financial_transaction_update'),
]