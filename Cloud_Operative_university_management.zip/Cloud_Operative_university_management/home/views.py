from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import UserAccount, UniversityService, FinancialTransaction
from .forms import UserAccountForm, UniversityServiceForm, FinancialTransactionForm
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout


# User Account Management

def index(request):
    return render(request, 'index.html')
    

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home:index')
    return render(request, 'login.html')

def signup_view(request):
    if request.method == 'POST':
        form = UserAccountForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home:login')
    else:
        form = UserAccountForm()
    return render(request, 'signup.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home:index')
        
@login_required
def user_account_list(request):
    user_accounts = UserAccount.objects.all()
    return render(request, 'user_account_list.html', {'user_accounts': user_accounts})

@login_required
def user_account_detail(request, pk):
    user_account = get_object_or_404(UserAccount, pk=pk)
    return render(request, 'user_account_detail.html', {'user_account': user_account})

@login_required
def user_account_update(request, pk):
    user_account = get_object_or_404(UserAccount, pk=pk)
    if request.method == 'POST':
        form = UserAccountForm(request.POST, instance=user_account)
        if form.is_valid():
            form.save()
            return redirect('home:user_account_list')
    else:
        form = UserAccountForm(instance=user_account)
    return render(request, 'user_account_update.html', {'form': form})

# University Service Management
@login_required
def university_service_list(request):
    university_services = UniversityService.objects.all()
    return render(request, 'university_service_list.html', {'university_services': university_services})

@login_required
def university_service_detail(request, pk):
    university_service = get_object_or_404(UniversityService, pk=pk)
    return render(request, 'university_service_detail.html', {'university_service': university_service})

@login_required
def university_service_update(request, pk):
    university_service = get_object_or_404(UniversityService, pk=pk)
    if request.method == 'POST':
        form = UniversityServiceForm(request.POST, instance=university_service)
        if form.is_valid():
            form.save()
            return redirect('home:university_service_list')
    else:
        form = UniversityServiceForm(instance=university_service)
    return render(request, 'university_service_update.html', {'form': form})

# Financial Management
@login_required
def financial_transaction_list(request):
    financial_transactions = FinancialTransaction.objects.all()
    return render(request, 'financial_transaction_list.html', {'financial_transactions': financial_transactions})

@login_required
def financial_transaction_update(request, pk):
    financial_transaction = get_object_or_404(FinancialTransaction, pk=pk)
    if request.method == 'POST':
        form = FinancialTransactionForm(request.POST, instance=financial_transaction)
        if form.is_valid():
            form.save()
            return redirect('home:financial_transaction_list')
    else:
        form = FinancialTransactionForm(instance=financial_transaction)
    return render(request, 'financial_transaction_update.html', {'form': form})