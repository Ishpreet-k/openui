from django.contrib import admin
from home.models import *
# Register your models here.

admin.site.register(UserAccount)
admin.site.register(UniversityService)
admin.site.register(FinancialTransaction)