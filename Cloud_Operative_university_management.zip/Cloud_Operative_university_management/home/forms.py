# forms.py

from django import forms
from .models import UserAccount, UniversityService, FinancialTransaction

class UserAccountForm(forms.ModelForm):
    class Meta:
        model = UserAccount
        fields = ['username', 'email', 'first_name', 'last_name', 'phone_number', 'address']



class UniversityServiceForm(forms.ModelForm):
    class Meta:
        model = UniversityService
        fields = ['name', 'description']

class FinancialTransactionForm(forms.ModelForm):
    class Meta:
        model = FinancialTransaction
        fields = ['amount', 'transaction_date', 'description']